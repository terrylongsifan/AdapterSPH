#!/bin/sh

g++ sphAdapter.cpp -fPIC -shared -o libsphAdapter.so  -L/vol2/home/longsifan/software/precice/lib64 -lprecice
