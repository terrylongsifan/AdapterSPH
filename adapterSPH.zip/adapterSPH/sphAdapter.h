#include <iostream>
#include <stdio.h>
#include <string>
#include <algorithm>
#include "precice/SolverInterface.hpp"
//extern "C"{
using namespace std;
using namespace precice;

class sphAdapter
{
	public:
		//Parameterless
		sphAdapter();
	//	sphAdapter(int r, int s);
		sphAdapter(const std::string &participantName, const std::string &configurationFileName, int solverProcessIndex, int solverProcessSize) : interfaceSph(participantName, configurationFileName, solverProcessIndex, solverProcessSize)
		{ cout<<"sphAdapter: successful to constructor precice class!"<<endl;}
		
		
		//all method
		double initialize();
		double advance(double sph_dt);
		void finalize();	
	 	void testAdapter();	
		double getPrecice_dt();

		int getDim();
		int getMeshID(const std::string &meshName);
		void setMeshVertices(int meshID, int size, const double* positions, int* ids);	
		//can not to change the value 	
		void getMeshVertices(int meshID, int size, const int *ids, double *positions) const;	
	
		int getDataID(const std::string & dataName, int meshID);
		void readBlockVectorData(int dataID, int size, const int* valueIndices,  double* values);
		void writeBlockVectorData(int dataID, int size, const int* valueIndices, double* values);		

		//check the status of coupling (eg. procedure, finished or read data)
		bool isReadDataAvailable();
		bool isWriteDataRequired(double computedTimestepLength);
		bool isCouplingOngoing();

		//checkpoint
		const std::string& getReadCheckpoint();
		const std::string& getWriteCheckpoint();

		bool isActionRequired(const std::string & action);
		void markActionFulfilled(const std::string & action);

		//initial data
 		void initializeData();

		//setmesh
		int setMeshEdge(int meshID, int firstVertexID, int secondVertexID);
		void setMeshTriangle(int meshID, int firstEdgeID, int secondEdgeID, int thirdEdgeID);
		//for quad
		void setMeshQuad(int meshID, int firstEdgeID, int secondEdgeID, int thirdEdgeID, int fourthEdgeID);
		void setMeshQuadWithEdges(int meshID, int firstVertexID, int secondVertexID, int thirdVertexID, int fourthVertexID);		

		//deconstructor
		~sphAdapter(){
			cout<<"Adapter desturctor  called~"<<endl;
		}
	public:
		precice::SolverInterface interfaceSph;
	private:
		double precice_dt;
		int particleId;
		int rank;
		int size;
		
		
};

//}
