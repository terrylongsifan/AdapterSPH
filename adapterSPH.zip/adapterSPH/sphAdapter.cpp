#include "sphAdapter.h"

//sphAdapter::sphAdapter(int r, int s){
//	rank=r;
//	size=s;
//}
//Establish connection with precice
double sphAdapter::initialize(){
//	precice::SolverInterface precice("FluidSolver","precice-config.xml",rank,size);
//	interfaceSph=&precice;
//	this->interfaceSph("FluidSolver","precice-config.xml",rank,size);
	cout<<"prepare for initialize"<<endl;
	precice_dt = this->interfaceSph.initialize();	
	cout<<"successfully linked to precice~(*_*)~"<<endl;
	return precice_dt;
}

//advance method
double sphAdapter::advance(double dt){
	double sph_dt;
	sph_dt = interfaceSph.advance(dt);
	return sph_dt;
}

//check if the coupling is going on
bool sphAdapter::isCouplingOngoing(){

	bool flag = interfaceSph.isCouplingOngoing();
	return flag;
}

//check the data need to read
bool sphAdapter::isReadDataAvailable(){
	
	bool flag = interfaceSph.isReadDataAvailable();
	return flag;
}

//check the data need to written
bool sphAdapter::isWriteDataRequired(double computedTimestepLength){

	bool flag = interfaceSph.isWriteDataRequired(computedTimestepLength);
	return flag;
}

//checkpoint read for implicit coupling
const std::string& sphAdapter::getReadCheckpoint(){

	const std::string& coric = precice::constants::actionReadIterationCheckpoint();
	return coric;
}

//checkpoint write for implicit coupling
const std::string& sphAdapter::getWriteCheckpoint(){

	const std::string& cowic = precice::constants::actionWriteIterationCheckpoint();
	return cowic;
}

bool sphAdapter::isActionRequired(const std::string& action){
	
	bool action_flag = interfaceSph.isActionRequired(action);
	return action_flag;
}

void sphAdapter::markActionFulfilled(const std::string& action){
	
	interfaceSph.markActionFulfilled(action);
}


void sphAdapter::initializeData(){
	interfaceSph.initializeData();
}

int sphAdapter::setMeshEdge(int meshID, int firstVertexID, int secondVertexID){

	int edgeIDs = interfaceSph.setMeshEdge(meshID, firstVertexID, secondVertexID);
	return edgeIDs;
}

void sphAdapter::setMeshTriangle(int meshID, int firstEdgeID, int secondEdgeID, int thirdEdgeID){

	interfaceSph.setMeshTriangle(meshID, firstEdgeID, secondEdgeID, thirdEdgeID);
	cout<<"successful set meshTriangle!"<<endl;
}

//set mesh connection
void sphAdapter::setMeshQuad(int meshID, int firstEdgeID, int secondEdgeID, int thirdEdgeID, int fourthEdgeID){

	interfaceSph.setMeshQuad(meshID, firstEdgeID, secondEdgeID, thirdEdgeID, fourthEdgeID);
	cout<<"successful set meshQuad!"<<endl;
}
void sphAdapter::setMeshQuadWithEdges(int meshID, int firstVertexID, int secondVertexID, int thirdVertexID, int fourthVertexID){

	interfaceSph.setMeshQuadWithEdges(meshID, firstVertexID, secondVertexID, thirdVertexID, fourthVertexID);
}

//finalize method
void sphAdapter::finalize(){

	interfaceSph.finalize();
	cout<<"end of precice coupling~"<<endl;	
}

//test the precice
void sphAdapter::testAdapter(){
	cout<<"prepare to excute initialize....please wait a few minutes...."<<endl;
//	cout<<"initial="<<interfaceSph->initialize<<endl;
//	printf("initial = %p\n", interfaceSph);
	precice_dt=this->interfaceSph.initialize();
	cout<<"preice initialize() is connection, successful to test Adapter!"<<endl;
}

//get dimensions method
int sphAdapter::getDim(){
	return this->interfaceSph.getDimensions();
}

int sphAdapter::getMeshID(const std::string &meshName){
	int meshid = this->interfaceSph.getMeshID(meshName);	
	return meshid;
}

//set meshVertices
void sphAdapter::setMeshVertices(int meshID, int size, const double* positions, int *ids){
	this->interfaceSph.setMeshVertices(meshID, size, positions, ids);
}

//get the vertex coordinate
void sphAdapter::getMeshVertices(int meshID, int size, const int *ids, double *positions) const{
	this->interfaceSph.getMeshVertices(meshID, size, ids, positions);
}
	
int sphAdapter::getDataID(const std::string & dataName, int meshID){

	return this->interfaceSph.getDataID(dataName, meshID);
}
	
void sphAdapter::readBlockVectorData(int dataId, int size, const int* valueIndices, double* values){
	this->interfaceSph.readBlockVectorData(dataId, size, valueIndices, values);
}

void sphAdapter::writeBlockVectorData(int dataId, int size, const int* valueIndices, double* values){
	this->interfaceSph.writeBlockVectorData(dataId, size, valueIndices, values);

}

double sphAdapter::getPrecice_dt(){
	return this->precice_dt;
}
